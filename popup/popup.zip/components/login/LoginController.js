import m from '../../node_modules/mithril/mithril.mjs';
import Controller from '../Controller.js';
import FetchQL from '../../node_modules/fetchql/lib/fetchql.es.js';

const DLIVE_URL_ENDPOINT = 'https://graphigo.prd.dlive.tv/';
const DLIVE_QUERY = `
  query SearchPage($text: String!, $first: Int) {
    search(text: $text) {
      users(first: $first) {
        list {
          displayname
          avatar
          id
          username
          displayname
          followers {
            totalCount
          }
        }
      }
    }
  }`;

let displayName = '';
let users = [];

class LoginController extends Controller {

  get displayName () { return displayName; }
  get users() { return users; }

  selectUser (event) {

  }

  buildDliveQuery () {
    return new FetchQL ({url: DLIVE_URL_ENDPOINT });
  }

  onUsersSearched (response) {
    users = response.data.search.users.list;
    m.render.strategy ('diff');
    m.redraw ();
  }

  searchUsers (displayName) {
    if (!displayName) { return; }
    return this.buildDliveQuery ().query ({
      operationName: 'SearchPage',
      variables: {
        text: displayName,
        first: 5
      },
      query: DLIVE_QUERY
    });
  }
  
  search (vnode) {
    if (!vnode) { return; }
    let input = vnode.dom.querySelector ('#display-name');
    displayName = input.value;
    this.searchUsers (displayName).then (this.onUsersSearched);
  }
}

export default LoginController;