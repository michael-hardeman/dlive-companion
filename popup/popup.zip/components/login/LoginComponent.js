import m from '../../node_modules/mithril/mithril.mjs';
import Component from '../Component.js';
import LoginController from './LoginController.js';

const controller = new LoginController();

class LoginComponent extends Component {

  usersList (users) { 
    if (!users) { return m('div'); }
    return users.map ((user) => {
      return m('div', {class: 'tile tile-centered', key: user.id}, [
        m('div', {class: 'tile-icon'}, [
          m('img', {class: 'icon centered'}, {src: user.avatar})
        ]),
        m('div', {class: 'tile-content'}, [
          m('div', {class: 'tile-title'}, user.displayName),
          m('small', {class: 'tile-subtitle text-grey'}, user.followers.totalCount)
        ])
      ]);
    });
  }

  view (vnode) {
    return m('popup-login', {class: 'relative form-group'}, [
      m('label', {class: 'form-label', for:'display-name'}),
      m('div', {class: 'has-icon-right'}, [
        m('input', {
          id: 'display-name',
          class: 'form-input',
          type: 'text',
          placeholder: 'Display Name',
          value: controller.displayName,
          autofocus: true
        }),
        m('i', {class: 'form-icon icon icon-search', onclick: controller.search.bind(controller, vnode) })
      ]),
      m('div', this.usersList(controller.users))
    ]);
  }
}

export default LoginComponent;