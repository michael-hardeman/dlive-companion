class Controller {}

export default Controller;