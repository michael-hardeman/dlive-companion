import m from '../../node_modules/mithril/mithril.mjs';
import Component from '../Component.js';

class FollowedComponent extends Component {
  view () {
    return m('popup-followed', {class: 'relative'}, [
      m('h1', {class: 'title'}, 'Followed')
    ]);
  }
}

export default FollowedComponent;