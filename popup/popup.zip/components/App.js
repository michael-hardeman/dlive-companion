import m from '../node_modules/mithril/mithril.mjs';
import PopupComponent from './popup/PopupComponent.js';

m.mount(document.body, new PopupComponent());